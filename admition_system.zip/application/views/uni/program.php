<?php include_once "header.php"?>
	<!--pages-starts-->
	<div class="pages">
		<div class="container">
			 <center><h2 class="top">Programs We Offer</h2></center>
				<div class="row" style="margin-top:15px;">
					<div class="col-md-3 col-md-offset-2">
						<a href="#">BSIT</a>
					</div>
					<div class="col-md-3">
						<a href="#">BSCS</a>
					</div>
					<div class="col-md-3">
						<a href="#">BSSE</a>
					</div>

				</div>
				<div class="row" style="margin-top:15px;">
					<div class="col-md-3 col-md-offset-2">
						<a href="#">BS MAthematics</a>
					</div>
					<div class="col-md-3">
						<a href="#">BS PHYSICS</a>
					</div>
					<div class="col-md-3">
						<a href="#">BS CHEMISTORY</a>
					</div>

				</div>
				<div class="row" style="margin-top:15px;">
					<div class="col-md-3 col-md-offset-2">
						<a href="#">BBA</a>
					</div>
					<div class="col-md-3">
						<a href="#">BCOM</a>
					</div>
					<div class="col-md-3">
						<a href="#">BS ELECTRONICS</a>
					</div>

				</div>
				<div class="row" style="margin-top:15px;">
					<div class="col-md-3 col-md-offset-2">
						<a href="#">BS ELECTRICAL</a>
					</div>
					<div class="col-md-3">
						<a href="#">BS MACHANICAL</a>
					</div>
					<div class="col-md-3">
						<a href="#">BS CIVIL</a>
					</div>

				</div>
				
			
			 
		</div>	
	</div>	
	<!----pages-end---->
	<!---->
<?php include_once "footer.php"?>