</div>
<div class="copywrite">
	 <div class="container">
		 <p style="text-align:center">Copyright © 2017 University. All rights reserved | Design by Author</p>
	 </div>
</div>
<!---->
</body>
</html>