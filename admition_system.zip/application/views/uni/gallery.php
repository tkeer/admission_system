<?php include_once "header.php"?>
<!---->
<div class="gallery">
	 <div class="container">
		 <h2>Gallery</h2>
		 <div class="event-pics">
				<a class="fancybox" href="<?= base_url('assets/images/1.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/1.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/2.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/2.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/3.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/3.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/4.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/4.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<div class="clearfix"></div>
				<a class="fancybox" href="<?= base_url('assets/images/5.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/5.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/6.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/6.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/7.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/7.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/8.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/8.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<div class="clearfix"></div>
				<a class="fancybox" href="<?= base_url('assets/images/9.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/9.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/10.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/10.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/2.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/11.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<a class="fancybox" href="<?= base_url('assets/images/1.jpg');?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?= base_url('assets/images/1.jpg');?>" class="img-style row6" alt=""><span> </span></a>
				<div class="clearfix"></div>
		 </div>
	 </div>
</div>
<!---->
<?php include_once "footer.php"?>