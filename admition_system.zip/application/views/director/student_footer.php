<script
  src="<?= base_url('assets/js/jquery.js') ?>"></script>
<script scr="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
</body>
</html>