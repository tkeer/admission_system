<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends MY_Controller {
	
	public function __construct(){
		parent:: __construct();
		if( ! $this->session->userdata('id'))
			return redirect('uni');
		$this->load->model('course');
	}
	public function index(){
		$this->load->view('students/welcome');
	}
	public function dashboad(){
		$result = $this->course->dep_list();
		$this->load->view('students/home', ['result' => $result]);
	}
	public function add_course($course_id){
		$id = $this->session->userdata('id');
		$data = array(
			'course_id'    => 	$course_id,
			'st_id' 	  => 	$id	
		);
		$result = $this->course->insert_course($data);
		if($result == 1){
			$this->session->set_flashdata('item', 'You have Already selected this course.');
			return redirect('student/dashboad');
		}else if($result ==2 ){
			$this->session->set_flashdata('insert_item', 'You have Successfully selected this course.');
			return redirect('student/dashboad');
		}
		else if($result ==3 ){
			$this->session->set_flashdata('seats', 'seats are Full if you want to choose this subject then you must contact with the admin');
			return redirect('student/dashboad');
		}else{
			$this->session->set_flashdata('subject_error', 'You have Already selected Five courses.');
			return redirect('student/dashboad');
		}
	}
	public function subjects(){
		$id = $this->session->userdata('id');
		$result = $this->course->selected_subjects($id);
		if($result){
			$this->load->view('students/subjects', ['sub'=>$result]);
		}else{
			$this->session->set_flashdata('subject', 'No Selected Subjects, Please select your subjects');
			$this->load->view('students/subjects', ['sub'=>$result]);
		}
	}
	public function drop($course_id){
		$st_id =  $this->session->userdata('id');
		$result = $this->course->drop_sub($course_id, $st_id);
		if($result){
			$this->session->set_flashdata('subject_drop', 'You have successfully drop this subject.');
			return redirect('student/subjects');
		}else{
			$this->session->set_flashdata('subject_drop', 'Query Fiald, Please try again.');
			return redirect('student/subjects');
		}
	}
	public function logout(){
			$this->session->unset_userdata('id');
			return redirect('uni');
		}
		
		
		
		
		
		
		 public function get_province()
	{  
		$country_id = $this->input->post('country_id');
                
                
                $this->load->model('course','dep_model');
		$provinces = $this->dep_model->list_files($country_id);
                $result ='';    
                $result .='<table class="table">'
                            . '<tr>'
                            . '<th>Title</th>'
                            . '<th>description</th>'
                            . '<th>Date</th>'
                            . '</tr>';
                            foreach ($provinces as $province) {
                                $result .='<tr>'
                            . '<td>'.$province->course_id.'</td>'
                            . '<td>'.$province->course_name.'</td>'
                            .'</tr>';
                                }
                            $result .='</table>';
                            echo json_encode($result);
		}
		
}