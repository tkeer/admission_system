<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {
	
	public function __construct(){
		parent::__construct();
		if(  $this->session->userdata('admin_id'))
			return redirect('admin');
		$this->load->model('admin_login','login');
	}
	public function index(){
		$this->load->view('admin/login');
	}
	
	public function user_login(){
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('inputEmail', 'Username', 'required');
		$this->form_validation->set_rules('inputPassword', 'Password', 'required');
		$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');
			
			if( $this->form_validation->run() ) {
				$email = $this->input->post('inputEmail');
				$pass = $this->input->post('inputPassword');
				
				
					$result = $this->login->login( $email, $pass );
				if($result){
					if($result->name == "admin"){
						$this->session->set_userdata('admin_id',$result->admin_id);
						return redirect('admin');
					}else if( $result->name == "teacher" ){
						echo "Teacher"; exit;
					}else if( $result->name == "hod" ){
						echo "HOD"; exit;
					}else {
						echo "Director"; exit;
					}
				}else{
					$this->session->set_flashdata('login_field', 'Login faild Please try again');
					$this->load->view('admin/login');
				}
		}else {
				$this->load->view('admin/login');
				}
}
}
