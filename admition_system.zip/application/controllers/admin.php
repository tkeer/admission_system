<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MY_Controller {
	
	public function __construct(){
		parent::__construct();
		if( ! $this->session->userdata('admin_id'))
			return redirect('login');
		$this->load->model('admin_pro','pro');
	}
	public function index(){
		
		$this->load->view('admin/home');
	}
	public function Add_session(){
		$this->load->view('admin/add');
	}
	public function session(){
		$session = $this->input->post_get('sec_name');
		$result = $this->pro->add_sec($session);
			if($result){
				$this->session->set_flashdata('add_session', 'You have successfully Added the New Session.');
			return redirect('admin');
			}else{
				$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
				return redirect('admin');
			}
	}
	public function List_session(){
		$result = $this->pro->list_sess();
			if($result){
				$this->load->view('admin/list_sec', ['result'=>$result]);
			}else{
				echo "not";
			}
	}
	public function Edit_sec($id){
		$result = $this->pro->edit_sec($id);
		if($result){
			$this->load->view('admin/edit_sec', ['result'=>$result]);
		}else{
			return redirect('admin/List_session');
		}
	}
	public function update_sec(){
		$session = $this->input->post_get('sec_name');
		$id = $this->input->post_get('id');
		$result = $this->pro->update_sec($session, $id);
			if($result){
				$this->session->set_flashdata('add_session', 'You have successfully Updated Session.');
			return redirect('admin/List_session');
			}else{
				$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
				return redirect('admin/List_session');
			}
		
	}
	public function Delete_sec($id){
		$result = $this->pro->delete_sec($id);
		if($result){
			$this->session->set_flashdata('add_session', 'You have successfully Deleted the Session.');
			return redirect('admin/List_session');
		}else{
			$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
			return redirect('admin/List_session');
		}
	}
	// department query handling  start
	public function add_view(){
		$this->load->view('admin/add_dep');
	}
	public function List_dep(){
		$result = $this->pro->list_dep();
			if($result){
				$this->load->view('admin/list_dep', ['result'=>$result]);
			}else{
				echo "not";
			}
	}
	public function dep(){
		$id = $this->input->post_get('phonenumber');
		$dep_name = $this->input->post_get('firstname');
		$data = array(
			'id'      =>  $id ,
			'name'	  =>  $dep_name 
		);
		$result = $this->pro->add_dep($data);
			if($result){
				$this->session->set_flashdata('add_dep', 'You have successfully Added the New Department.');
			return redirect('admin/List_dep');
			}else{
				$this->session->set_flashdata('faild_dep', 'Query faild, please try Again !');
				return redirect('admin');
			}
	}
	
	public function Edit_dep($id){
		$result = $this->pro->edit_dep($id);
		if($result){
			$this->load->view('admin/edit_dep', ['result'=>$result]);
		}else{
			return redirect('admin/List_dep');
		}
	}
	public function update_dep(){
		$name = $this->input->post_get('firstname');
		$dp_id = $this->input->post_get('dp_id');
		$id = $this->input->post_get('phonenumber');
		$data = array(
			'id'		=>   $id,
			'name'		=>	$name	
		);
		$result = $this->pro->update_dep($data, $dp_id);
			if($result){
				$this->session->set_flashdata('add_session', 'You have successfully Updated Department.');
			return redirect('admin/List_dep');
			}else{
				$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
				return redirect('admin/List_dep');
			}
	}
	public function Delete_dep($id){
		$result = $this->pro->delete_dep($id);
		if($result){
			$this->session->set_flashdata('add_session', 'You have successfully Deleted the Department.');
			return redirect('admin/List_dep');
		}else{
			$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
			return redirect('admin/List_dep');
		}
	}
	// end department query handling...
	
	//teacher handling code...
	public function teach(){
		$this->load->view('admin/add_teach');
	}
	public function List_teach(){
		$result = $this->pro->list_teach();
			if($result){
				$this->load->view('admin/list_teach', ['result'=>$result]);
			}else{
				echo "not";
			}
		
	}
	public function add_teach(){
		$pass = $this->input->post_get('exampleInputPassword2');
		$name = $this->input->post_get('firstname');
		$data = array(
			'name'      =>  $name ,
			'pass'	  =>  $pass 
		);
		$result = $this->pro->add_teach($data);
			if($result){
				$this->session->set_flashdata('add_dep', 'You have successfully Added the New Department.');
			return redirect('admin/List_teach');
			}else{
				$this->session->set_flashdata('faild_dep', 'Query faild, please try Again !');
				return redirect('admin/List_teach');
			}
		
	}
	public function Edit_teach($id){
		$result = $this->pro->edit_teach($id);
		if($result){
			$this->load->view('admin/edit_teach', ['result'=>$result]);
		}else{
			return redirect('admin/List_teach');
		}
	}
	public function update_teach(){
		$name = $this->input->post_get('firstname');
		$id = $this->input->post_get('dp_id');
		$pass = $this->input->post_get('exampleInputPassword2');
		$data = array(
			'name'		=>   $name,
			'pass'		=>	$pass	
		);
		$result = $this->pro->update_teach($data, $id);
			if($result){
				$this->session->set_flashdata('add_session', 'You have successfully Updated Record.');
			return redirect('admin/List_teach');
			}else{
				$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
				return redirect('admin/List_teach');
			}
	}
	public function Delete_teach($id){
		$result = $this->pro->delete_teach($id);
		if($result){
			$this->session->set_flashdata('add_session', 'You have successfully Deleted the Record.');
			return redirect('admin/List_teach');
		}else{
			$this->session->set_flashdata('faild_session', 'Query faild, please try Again !');
			return redirect('admin/List_teach');
		}
	}
	public function logout(){
			$this->session->unset_userdata('admin_id');
			return redirect('login');
		}
}