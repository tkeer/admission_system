<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_pro extends CI_Model {
	//start session query
	
	public function add_sec($name){
		$data = array(
			'sec'=>$name
		);
		$q = $this->db
				  ->insert('sec', $data);
			return $q;
	}
	public function list_sess(){
		$query =	$this->db->select()
							 ->from('sec')
							 ->get();
				return $query->result();
	}
	public function edit_sec($id){
		$query =	$this->db->select()
							 ->from('sec')
							 ->where('sec_id',$id)
							 ->get();
				return $query->row();
	}
	public function update_sec($data, $id){
		
		$query = $this->db->set('sec', $data)
				->where('sec_id', $id)
				->update('sec'); 
			return $query;
	}
	public function delete_sec($id){
		$query = $this->db->where('sec_id', $id)
				 ->delete('sec');
			return $query;
	}
	//end all session query...
	
	//start department query...
	public function add_dep($data){
		$q = $this->db
				  ->insert('depart', $data);
			return $q;
	}
	public function list_dep(){
		$query =	$this->db->select()
							 ->from('depart')
							 ->get();
				return $query->result();
	}
	public function edit_dep($id){
		$query =	$this->db->select()
							 ->from('depart')
							 ->where('dep_id',$id)
							 ->get();
				return $query->row();
	}
	public function update_dep($data, $id){
		
		$query = $this->db->set( $data)
				->where('dep_id', $id)
				->update('depart'); 
			return $query;
	}
	public function delete_dep($id){
		$query = $this->db->where('dep_id', $id)
				 ->delete('depart');
			return $query;
	}
	//end department query...
	public function add_teach($data){
			$q = $this->db
				  ->insert('teacher', $data);
			return $q;
	}
	public function list_teach(){
		$query =	$this->db->select()
							 ->from('teacher')
							 ->get();
				return $query->result();
	}
	public function edit_teach($id){
		$query =	$this->db->select()
							 ->from('teacher')
							 ->where('id',$id)
							 ->get();
				return $query->row();
	}
	public function update_teach($data, $id){
		$query = $this->db->set($data)
				->where('id', $id)
				->update('teacher'); 
			return $query;
	}
	public function delete_teach($id){
		$query = $this->db->where('id', $id)
				 ->delete('teacher');
			return $query;
	}
	
	
}