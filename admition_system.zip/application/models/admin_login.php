<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_login extends CI_Model {
	
	public function login($email,$pass){
		
		$query =	$this->db->select()
							 ->from('admin')
							 ->where(['email'=>$email,'pass'=>$pass])
							 ->join('role', 'role.role_id = admin.role_id', 'left')
							 ->get();
							 
					if($query->num_rows() > 0 ) {
						return $query->row();
					} else {
						return FALSE;
					}
				
	}
	
	
	
	
}